<div class="column menu">
	<h1>Sfoglia per genere</h1>
	<hr>
	<ul>
		<li><a href="genere.php?categoria=avventura">Avventura</a></li>
		<li><a href="genere.php?categoria=corse">Corse</a></li>
		<li><a href="genere.php?categoria=GDR">GDR</a></li>
		<li><a href="genere.php?categoria=indie">Indie</a></li>
		<li><a href="genere.php?categoria=retro">Retr&ograve;</a></li>
		<li><a href="genere.php?categoria=simulazione">Simulazione</a></li>
		<li><a href="genere.php?categoria=sport">Sport</a></li>
	</ul>
</div>
