<!DOCTYPE html>
<html>
	<head>
		<title>Assistenza | NIGG Games</title>
		<meta charset="utf-8">
		<meta name="author" content="Gruppo 16">
		<meta name="keywords" content="games, videogiochi, recensione, descrizione">
		<link rel="icon" type="ico" href="favicon.ico">
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>

	<?php session_start(); ?>
	<body>
		<div id="container">
			<?php include "header.php";?>

			<div class="row">
			    <?php include "vmenu.php";?>

				
			    <div class="column content">
					<h1>Contatti</h1>
					<div style="float:left;width:50%;margin-left:5%;"> 
			    		<div itemscope itemtype="https://schema.org/Person" class="contact-box" style="--my-color-var: #d7c051;">
				    		<img src="immaginicontatti/yellow.png">
				    		<ul>
								<li class="username">
									<span itemprop="givenName">Giorgio</span>
									<span itemprop="familyName">Falcone</span>
								</li>
				    			<li itemprop="telephone" class="tel">Tel: 3275740291</li>
				    			<li class="mail">E-mail: <a itemprop="email" href="mailto:g.falcone32@studenti.unisa.it">G.FALCONE32@studenti.unisa.it</a></li>
				    			<li itemprop="jobTitle" class="job">Sviluppatore Back-End</li>
				    		</ul>
			    		</div>

			    		<div itemscope itemtype="https://schema.org/Person" class="contact-box" style="--my-color-var: #60c5ff;">
			    			<img src="immaginicontatti/blue.png">
			    			<ul>
								<li class="username">
									<span itemprop="givenName">Giacomo</span>
									<span itemprop="familyName">Albamonte</span>
								</li>
			    				<li itemprop="telephone" class="tel">Tel: 3209732978</li>
			    				<li class="mail">E-mail: <a itemprop="email" href="mailto:g.albamonte@studenti.unisa.it">G.ALBAMONTE@studenti.unisa.it</a></li>
			    				<li itemprop="jobTitle" class="job">Sviluppatore Front-End</li>
			    			</ul>
			    		</div>

			    		<div itemscope itemtype="https://schema.org/Person" class="contact-box" style="--my-color-var: #339a5f;">
			    			<img src="immaginicontatti/green.png">
			    			<ul>
								<li class="username">
									<span itemprop="givenName">Giuseppina</span>
									<span itemprop="familyName">Di Paolo</span>
								</li>
			    				<li itemprop="telephone" class="tel">Tel: 3341466596</li>
			    				<li class="mail">E-mail: <a itemprop="email" href="mailto:g.dipaolo5@studenti.unisa.it">G.DIPAOLO5@studenti.unisa.it</a></li>
			    				<li itemprop="jobTitle" class="job">Web Analyst</li>
			    			</ul>
			    		</div>
                	</div>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3021.625856358192!2d14.78705431540676!3d40.77025307932557!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x133bc5ae68237343%3A0xe0b940ea7e610352!2sVia%20Giovanni%20Paolo%20II%2C%20132%2C%2084084%20Fisciano%20SA!5e0!3m2!1sit!2sit!4v1640794891200!5m2!1sit!2sit" width="400" height="300" style="border:0;float:left;margin:30px;margin-left:7%;margin-top:7%;border-radius: 10px;box-shadow: 7px 7px 20px 0 rgb(100, 100, 100);" allowfullscreen="" loading="lazy"></iframe>
				</div>
				
				

			    <?php include 'footer.html'; ?>
			</div>
		</div>
	</body>
</html>