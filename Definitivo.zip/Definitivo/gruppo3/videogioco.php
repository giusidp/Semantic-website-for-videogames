<?php require_once "logindb.php"; ?>
<?php
    /**
     * Making a SPARQL SELECT query
     *
     * This example creates a new SPARQL client, pointing at the
     * dbpedia.org endpoint. It then makes a SELECT query that
     * returns all of the countries in DBpedia along with an
     * english label.
     *
     * Note how the namespace prefix declarations are automatically
     * added to the query.
     *
     * @package    EasyRdf
     * @copyright  Copyright (c) 2009-2020 Nicholas J Humfrey
     * @license    http://unlicense.org/
     */

	require 'vendor/autoload.php'; 
    // Setup some additional prefixes for DBpedia
    \EasyRdf\RdfNamespace::set('dbc', 'http://dbpedia.org/resource/Category:');
    \EasyRdf\RdfNamespace::set('dbpedia', 'http://dbpedia.org/resource/');
    \EasyRdf\RdfNamespace::set('dbo', 'http://dbpedia.org/ontology/');
    \EasyRdf\RdfNamespace::set('dbp', 'http://dbpedia.org/property/');

    $sparql = new \EasyRdf\Sparql\Client('http://dbpedia.org/sparql');
?>

<!DOCTYPE html>
<html lang="it">
	<head>
		<title>Videogioco | NIGG Games</title>
		<meta charset="utf-8">
		<meta name="author" content="Gruppo 16">
		<meta name="keywords" content="games, videogiochi, recensione, descrizione">
		<link rel="icon" type="ico" href="favicon.ico">
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>

	<?php session_start(); ?>
	<body>
		<div id="container">
			<?php include "header.php";?>

			<div class="row">
				
			    <?php include "vmenu.php";?>

			    <div class="column content" itemscope itemtype="https://schema.org/VideoGame">

			    	<?php
						if (isset($_GET["id"])) {
						//significa che nella url è presente il parametro id (si dice che in querystring è presente id)
							
							$db = pg_connect($connection_string) or die('Impossibile connettersi al database: '.pg_last_error());

							$id = $_GET["id"];

							$sql = "SELECT nomegioco, copertina, consoleps4, consolexbox, consoleswitch, prezzolancio, trailer, descrizione, recensione, linkamazon, linkps4, linkxbox, linkswitch, prezzoamazon, prezzops4, prezzoxbox, prezzoswitch, valutazionestella FROM gioco WHERE idgioco = '$id'";

							$result = pg_query($db, $sql) or die(pg_last_error());
							if (!$result){
								echo "ERRORE QUERY: " . pg_last_error($db);
							}

							$row = pg_fetch_assoc($result);

							$nomegioco = $row["nomegioco"];
							$copertina = $row["copertina"];
							$consoleps4 = $row["consoleps4"];
							$consolexbox = $row["consolexbox"];
							$consoleswitch = $row["consoleswitch"];
							$prezzolancio = $row["prezzolancio"];
							$trailer = $row["trailer"];
							$descrizione = $row["descrizione"];
							$recensione = $row["recensione"];
							$linkamazon = $row["linkamazon"];
							$linkps4 = $row["linkps4"];
							$linkxbox = $row["linkxbox"];
							$linkswitch = $row["linkswitch"];
							$prezzoamazon = $row["prezzoamazon"];
							$prezzops4 = $row["prezzops4"];
							$prezzoxbox = $row["prezzoxbox"];
							$prezzoswitch = $row["prezzoswitch"];
							$valutazionestella = $row["valutazionestella"];
					?>
                            
                            <h1 itemprop="name"><?php echo $nomegioco;?></h1>
							
							<iframe itemprop="trailer" itemscope itemtype="https://schema.org/VideoObject" width="560" height="315" src="<?php echo $trailer; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							
							<div style="display:table;clear:both;margin-top:30px">
								<div class="container-descrizione">
									<img src="<?php echo $copertina; ?>" alt="Copertina">
									<div itemprop="description" class="container-infogioco">
										<h2>Descrizione</h2>
										<p><?php echo $descrizione; ?></p>
									</div>
								</div>

								<div class="card">
										<span>
										</span>
											<ul style="list-style-type:none;">
												<?php
													$gioco = str_replace("&apos;", "'", $nomegioco);
													$uri = $sparql->query(
														'SELECT ?software WHERE {?software dbp:name|rdfs:label "'.$gioco.'"@en .}'
													);
													$uri = explode("|", $uri);
													
													# Controlla se viene restituito uno uri dalla query
													if (count($uri)<4){
														$show = array();
														$result = array();
														for($i=0; $i<10; $i++){
															$show[$i] = "-";
															$result[$i] = "-";
														}
													}
													else {

														$relative = str_replace('dbpedia:', '', $uri[3]);
														$toChange = array("<",">"," ");
														$changeWith = array("%3C","%3E","%20");
														$url = str_replace($toChange, $changeWith, 'http://dbpedia.org/sparql?query=SELECT str(MIN(?data)) ?casaproduttrice ?musica ?genere WHERE {OPTIONAL {<http://dbpedia.org/resource/'.trim($relative).'> dbo:releaseDate ?data} OPTIONAL {<http://dbpedia.org/resource/'.trim($relative).'> dbo:developer|dbp:developer ?casaproduttrice} OPTIONAL {<http://dbpedia.org/resource/'.trim($relative).'> dbo:composer|dbp:composer ?musica} OPTIONAL {<http://dbpedia.org/resource/'.trim($relative).'> dbo:genre ?genere} FILTER(strlen(?musica)>0 )}&format=text/csv');
														$response = file_get_contents($url);
														$row = explode("\n", $response);
														$result = explode(",", $row[1]);
														$show = array();
														for($i=0; $i<count($result); $i++){
															if($result[$i]=="")
																$result[$i]="-";
															$show[$i] = str_replace("http://dbpedia.org/resource/","",$result[$i]);
															$show[$i] = str_replace("_"," ",$show[$i]);
														}

													}
													
												?>
												<li style="padding-bottom: 7px"><b>Data di rilascio</b>: <?php echo str_replace("\"","",$show[0]); ?></li>
												<li style="padding-bottom: 7px"><b>Casa produttrice</b>: <?php if ($result[1]!="-" && str_contains($result[1], "http")){?> <a target="blank" href=<?php echo $result[1];?>><?php } echo str_replace("\"","",$show[1]); ?></a></li>
												<li style="padding-bottom: 7px"><b>Compositore</b>: <?php if ($result[2]!="-" && str_contains($result[2], "http")){?><a target="blank" href=<?php echo $result[2];?>><?php } echo str_replace("\"","",$show[2]); ?></a></li>
												<li style="padding-bottom: 7px"><b>Genere</b>: <?php if ($result[3]!="-" && str_contains($result[3], "http")){?><a target="blank" href=<?php echo $result[3];?>><?php } echo str_replace("\"","",$show[3]); ?></a></li>
											</ul>
									</div>
							</div>

							<div itemprop="review" itemscope itemtype="https://schema.org/Review" class="container-recensione">

								<h2 itemprop="name">La nostra recensione</h2>
								<span itemprop="itemReviewed" itemscope itemtype="https://schema.org/VideoGame" style="display:none">
									<span itemprop="name">The Legend of Zelda: Breath of the Wild</span>
								</span>
								<span itemprop="author" itemscope itemtype="https://schema.org/Person" style="display:none">
        							<span itemprop="name">NIGG Games</span>
      							</span>

								<?php 
									if (empty($_SESSION["uname"])) {
								?>
										<p class="alertlogin">Effettua il login per poter leggere la nostra recensione!</p>	
								<?php
									}
									else{
								?>
										<p itemprop="reviewBody" id="recensione"><?php echo $recensione; ?></p>
										<img src="<?php echo $valutazionestella; ?>">
								<?php
									}
								?>
							</div>

							<div class="container-acquisto">
								<h2>Dove acquistarlo?</h2>
								<?php 
									if (empty($_SESSION["uname"])) {
								?>
										<p class="alertlogin">Effettua il login per acquistare il prodotto al miglior prezzo!</p>	
								<?php
									}
									else{
								?>
										<div class="riferimenti">
											<ul>
												<li><?php
														if (empty($linkamazon)) {
														}
														else {
													?>	
															<a href="<?php echo $linkamazon; ?>" target="_blank">
													<?php			
														}
													?>
													<img src="siti/amazon.png" alt="Amazon"></a><p itemscope itemtype="https://schema.org/Offer"><span itemprop="price"><?php echo $prezzoamazon; ?></span></p></li>
												<li><?php
														if (empty($linkps4)) {
														}
														else {
													?>	
															<a href="<?php echo $linkps4; ?>" target="_blank">
													<?php			
														}
													?>
													<img src="siti/ps4store.png" alt="PlayStation Store"></a><p itemscope itemtype="https://schema.org/Offer"><span itemprop="price"><?php echo $prezzops4; ?></span></p></li>
												<li><?php
														if (empty($linkxbox)) {
														}
														else {
													?>	
															<a href="<?php echo $linkxbox; ?>" target="_blank">
													<?php			
														}
													?>
													<img src="siti/Xbox.png" alt="Xbox"></a><p itemscope itemtype="https://schema.org/Offer"><span itemprop="price"><?php echo $prezzoxbox; ?></span></p></li>
												<li><?php
														if (empty($linkswitch)) {
														}
														else {
													?>	
															<a href="<?php echo $linkswitch; ?>" target="_blank">
													<?php			
														}
													?>
													<img src="siti/nintendo.png" alt="Nintendo eShop"></a><p itemscope itemtype="https://schema.org/Offer"><span itemprop="price"><?php echo $prezzoswitch; ?></span></p></li>
											</ul>
										</div>	
										<?php
											}
										?>
								</div>

								<div class="container-votazioni">
								<?php 

									$angryquery = "SELECT count(*) as col1 FROM reazioni WHERE reaction = 'angry' AND idvideogame = '$id'";
									$angryres = pg_query($db, $angryquery) or die(pg_last_error());
									if (!$angryres){
										echo "ERRORE QUERY: " . pg_last_error($db);
									}
									$row1 = pg_fetch_assoc($angryres);
									$angry = $row1['col1'];

									$bluelikequery = "SELECT count(*) as col2 FROM reazioni WHERE reaction = 'bluelike' AND idvideogame = '$id'";
									$bluelikeres = pg_query($db, $bluelikequery) or die(pg_last_error());
									if (!$bluelikeres){
										echo "ERRORE QUERY: " . pg_last_error($db);
									}
									$row2 = pg_fetch_assoc($bluelikeres);
									$bluelike = $row2['col2'];

									$wowquery = "SELECT count(*) as col3 FROM reazioni WHERE reaction = 'wow' AND idvideogame = '$id'";
									$wowres = pg_query($db, $wowquery) or die(pg_last_error());
									if (!$wowres){
										echo "ERRORE QUERY: " . pg_last_error($db);
									}
									$row3 = pg_fetch_assoc($wowres);
									$wow = $row3['col3'];

									if (empty($_SESSION["uname"])) {
								?>
										<p class="alertlogin">Facci sapere la tua opinione! Effettua il login!</p>	
								<?php
									}
									else{
								?>
										<h2>Facci sapere la tua opinione</h2>
										<div class="emoji">
											<ul>
												<li itemscope itemtype="https://schema.org/AggregateRating">
													<a href="inserimentoReazioni.php?voto=bluelike&id=<?php echo $id;?>">
													<img src="stelle/like.png" alt="Like reaction" onmouseover="big(this)" onmouseout="normal(this)"></a>
													<p itemprop="ratingCount ratingValue bestRating worstRating" class="contatore"><?php echo $bluelike; ?></p>
													<span itemprop="itemReviewed" itemscope itemtype="https://schema.org/VideoGame" style="display:none">
														<span itemprop="name"><?php echo $nomegioco;?></span>
													</span>
												</li>
												<li itemscope itemtype="https://schema.org/AggregateRating">
													<a href="inserimentoReazioni.php?voto=angry&id=<?php echo $id;?>">
													<img src="stelle/angry.png" alt="Angry reaction" onmouseover="big(this)" onmouseout="normal(this)"></a>
													<p itemprop="ratingCount ratingValue bestRating worstRating" class="contatore"><?php echo $angry; ?></p>
													<span itemprop="itemReviewed" itemscope itemtype="https://schema.org/VideoGame" style="display:none">
														<span itemprop="name"><?php echo $nomegioco;?></span>
													</span>
												</li>
												<li itemscope itemtype="https://schema.org/AggregateRating">
													<a href="inserimentoReazioni.php?voto=wow&id=<?php echo $id;?>">
													<img src="stelle/wow.png" alt="Wow reaction" onmouseover="big(this)" onmouseout="normal(this)"></a>
													<p itemprop="ratingCount ratingValue bestRating worstRating" class="contatore"><?php echo $wow; ?></p>
													<span itemprop="itemReviewed" itemscope itemtype="https://schema.org/VideoGame" style="display:none">
														<span itemprop="name"><?php echo $nomegioco;?></span>
													</span>
												</li>
											</ul>
										</div>	
										<?php
											}       
										?>
								</div>
					<?php
						
						}
						pg_close($db);
					?> 


				</div>

			</div>

			<?php include 'footer.html'; ?>

		</div>

	</body>
</html>

<script>
	function big(x){
		x.style.height="50px";
		x.style.width="50px";
	}

	function normal(x){
		x.style.height="40px";
		x.style.width="40px";
	}
</script>














































<?php
    # dbr: dbpedia resource ---> Soggetto (es. Super Mario)   http://dbpedia.org/resource/SuperMario
	# dbp: dbpedia property    mappa dbo ---> Proprty 
	# a sostituisce rdf:type
	function getGameUri($name){
		$toChange = array("<",">"," ","\"");
		$changeWith = array("%3C","%3E","%20","%22");
		$url = str_replace($toChange, $changeWith, "http://dbpedia.org/sparql?query=SELECT ?game WHERE {?game dbp:name|rdfs:label \"".$name."\"@en}&format=text/csv");
		$response = file_get_contents($url);
		$part = explode("\n", $response);
		return str_replace("\"", "", $part[1]);
	}
?>

