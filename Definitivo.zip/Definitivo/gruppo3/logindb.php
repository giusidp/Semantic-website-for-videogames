<?php
	$host = 'localhost';
	$db = 'gruppo3';
	$usernamedb = 'www';
	$passworddb = 'tsw2020';
	$connection_string = "host=$host dbname=$db user=$usernamedb password=$passworddb";
?>